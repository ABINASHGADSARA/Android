package com.ag.transaction;

import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;

public class utils {
    String tranId;
    String tranType;
}
