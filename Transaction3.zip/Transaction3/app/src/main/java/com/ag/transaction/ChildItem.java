package com.ag.transaction;

public class ChildItem {
    String tranID;
    String tranType;

    public String getTranID() {
        return tranID;
    }

    public void setTranID(String tranID) {
        this.tranID = tranID;
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    @Override
    public String toString() {
        return "ChildItem{" +
                "tranID='" + tranID + '\'' +
                ", tranType='" + tranType + '\'' +
                '}';
    }
}
